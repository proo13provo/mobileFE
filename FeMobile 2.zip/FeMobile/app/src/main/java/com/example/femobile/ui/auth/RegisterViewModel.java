package com.example.femobile.ui.auth;

public class RegisterViewModel {
}
